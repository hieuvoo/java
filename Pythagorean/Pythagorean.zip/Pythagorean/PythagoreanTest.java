public class PythagoreanTest{
    public static void main(String[] args){
        Pythagorean test = new Pythagorean();
        double result = test.calculateHypotenuse(3,4);
        System.out.println(result);
    }
}