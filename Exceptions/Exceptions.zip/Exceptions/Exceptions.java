import java.util.ArrayList;

public class Exceptions {
    public ArrayList<String> testing(){
        ArrayList<String> myList = new ArrayList<>();
        myList.add("13");
        myList.add("hello world");
        // myList.add(48);
        myList.add("Goodbye World");
        return myList;
    }
}