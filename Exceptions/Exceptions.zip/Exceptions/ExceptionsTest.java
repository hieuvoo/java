public class ExceptionsTest{
    public static void main(String[] args){
        Exceptions iD = new Exceptions();
        System.out.println(iD.testing());
    }
}