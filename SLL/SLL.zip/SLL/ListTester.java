public class ListTester{
    public static void main(String[] args){
        SLL list = new SLL();
        list.removeAt(0);
        list.printValues();
    }
}