public class FirstJavaProgram{
    public static void main(String[] args){
        System.out.println("My name is Hieu");
        System.out.println("I am 27 years young");
        System.out.println("My hometown is Falls Church, VA");        
    }
}